# This is the plugins directory __init__.py file

# It currently does nothing other than keep Python happy ;-)
